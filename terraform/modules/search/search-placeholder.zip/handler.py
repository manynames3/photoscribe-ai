"""Placeholder search Lambda for Phase 1."""

from __future__ import annotations

import json
from typing import Any


def handler(event: dict[str, Any], _context: Any) -> dict[str, Any]:
    """Return a placeholder search payload."""
    params = event.get("queryStringParameters") or {}
    query = params.get("q", "")
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(
            {
                "message": "search placeholder",
                "query": query,
                "results": [],
            }
        ),
    }

