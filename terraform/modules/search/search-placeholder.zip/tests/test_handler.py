from json import loads

from lambdas.search.handler import handler


def test_search_handler_returns_placeholder_payload() -> None:
    response = handler({"queryStringParameters": {"q": "test"}}, None)

    assert response["statusCode"] == 200
    assert loads(response["body"]) == {
        "message": "search placeholder",
        "query": "test",
        "results": [],
    }

