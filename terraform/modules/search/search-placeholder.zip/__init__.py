"""Search Lambda package."""

