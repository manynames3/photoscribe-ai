"""Ingest Lambda package."""

