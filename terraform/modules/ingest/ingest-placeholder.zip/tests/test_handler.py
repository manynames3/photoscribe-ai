from lambdas.ingest.handler import handler


def test_ingest_handler_returns_placeholder_response() -> None:
    event = {"Records": [{"s3": {"bucket": {"name": "photos"}, "object": {"key": "a.jpg"}}}]}

    response = handler(event, None)

    assert response["statusCode"] == 200
    assert '"records": 1' in response["body"]


def test_ingest_handler_counts_eventbridge_s3_event() -> None:
    event = {
        "source": "aws.s3",
        "detail-type": "Object Created",
        "detail": {"bucket": {"name": "photos"}, "object": {"key": "a.jpg"}},
    }

    response = handler(event, None)

    assert response["statusCode"] == 200
    assert '"records": 1' in response["body"]
