def test_vectors_placeholder_module_exists() -> None:
    from lambdas.ingest import vectors

    assert vectors.__doc__

