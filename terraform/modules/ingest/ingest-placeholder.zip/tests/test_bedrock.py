def test_bedrock_placeholder_module_exists() -> None:
    from lambdas.ingest import bedrock

    assert bedrock.__doc__

