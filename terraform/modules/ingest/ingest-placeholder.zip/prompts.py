"""Claude prompt definitions land in Phase 2."""

