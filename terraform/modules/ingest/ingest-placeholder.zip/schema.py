"""Pydantic schema lands in Phase 2."""

