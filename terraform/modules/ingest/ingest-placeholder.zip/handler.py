"""Placeholder ingest Lambda for Phase 1."""

from __future__ import annotations

import json
import logging
from typing import Any


LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)


def _count_records(event: dict[str, Any]) -> int:
    """Count records for either direct S3 notifications or EventBridge S3 events."""
    records = event.get("Records")
    if isinstance(records, list):
        return len(records)

    if event.get("source") == "aws.s3" and isinstance(event.get("detail"), dict):
        return 1

    return 0


def handler(event: dict[str, Any], _context: Any) -> dict[str, Any]:
    """Log the S3 event payload and return a placeholder response."""
    record_count = _count_records(event)
    LOGGER.info("received event with %s records", record_count)
    LOGGER.info(json.dumps(event))
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "ingest placeholder", "records": record_count}),
    }
